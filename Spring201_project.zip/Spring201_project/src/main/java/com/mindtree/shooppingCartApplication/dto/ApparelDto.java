package com.mindtree.shooppingCartApplication.dto;

public class ApparelDto {

	private String apprarelType;
	
	private String apparelBrand;
	
	private String apparelDesign;

	public String getApprarelType() {
		return apprarelType;
	}

	public void setApprarelType(String apprarelType) {
		this.apprarelType = apprarelType;
	}

	public String getApparelBrand() {
		return apparelBrand;
	}

	public void setApparelBrand(String apparelBrand) {
		this.apparelBrand = apparelBrand;
	}

	public String getApparelDesign() {
		return apparelDesign;
	}

	public void setApparelDesign(String apparelDesign) {
		this.apparelDesign = apparelDesign;
	}
	
	
	
}
